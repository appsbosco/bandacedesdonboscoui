# HooBank Landing page
Modern UI/UX Landing Page using React.js &amp; Tailwind CSS

![HooBank](https://i.ibb.co/BK1Hn0x/Screenshot-2022-08-08-at-4-05-48-PM.png)

**Figma Link** : https://www.figma.com/file/bUGIPys15E78w9bs1l4tgS/HooBank?node-id=310%3A485
